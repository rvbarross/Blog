const { Sequelize } = require('sequelize')

const sequelize = new Sequelize(
    'myblogdb',
    'root',
    'Scooby23#',
    {dialect: 'mysql'}
)

module.exports = sequelize