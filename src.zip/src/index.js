const express = require('express')
const app = express()
const port = 3000

const sequelize = require('./database')
const User = require('./model/user')
const userRouter = require('./routes/user')

app.use(express.json())

app.use('/user', userRouter)

app.listen(3000, async () =>{
    await sequelize.sync({ force: true })
    console.log("Server Up Baby!!");
})