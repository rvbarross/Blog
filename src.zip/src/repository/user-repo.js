const User = require('../model/user')

class UserRepository{

    insert(obj){
        const user = User.create({
            name: obj.name,
            email: obj.email
        })
        return user
    }
    
    async update(user){
        const jane = await User.findByPk(user.id)
        jane.name = user.name
        jane.email = user.email
        jane.save()
    }

    async delete(user){
        const jane = await User.findByPk(user.id)
        jane.destroy();
    }

    find(uid){
        return User.findByPk(uid)
    }

    findAll(){
        return User.findAll()
    }
}

module.exports = UserRepository